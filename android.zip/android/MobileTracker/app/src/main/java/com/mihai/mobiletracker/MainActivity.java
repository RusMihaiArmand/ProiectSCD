package com.mihai.mobiletracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;




//import com.android.volley.Request;
//import com.android.volley.Response;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import android.Manifest;

public class MainActivity extends AppCompatActivity implements View.OnClickListener  {




    private final Executor executor = Executors.newFixedThreadPool(1);
    private volatile Handler msgHandler;
    private String deviceId;


    private static final String POSITION_TEXT_FORMAT = "{" +
            "\"latitude\":\"%s\"," +
            "\"longitude\":\"%s\"," +
            "\"terminalId\":\"%s\"" +
            "}";



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_coords);

        Button sendButton = findViewById(R.id.button_T1);
        sendButton.setOnClickListener(this);
        this.deviceId = getPhoneId();
        msgHandler = new MsgHandler(this);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        }


    }




    public void onClick(View v) {
        executor.execute(new Runnable() {
            public void run() {
               Message msg = msgHandler.obtainMessage();
               msg.arg1 = sendPosition() ? 1 : 0;
               msgHandler.sendMessage(msg);

            }
        });
    }



    private static class MsgHandler extends Handler {
        private final WeakReference<Activity> sendActivity;
        public MsgHandler(Activity activity) {
            sendActivity = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            if (msg.arg1 == 1)
            {
                Toast.makeText(sendActivity.get().getApplicationContext(), "ALL GOOD!", Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(sendActivity.get().getApplicationContext(), "ERROR", Toast.LENGTH_LONG).show();
            }
        }
    }


    public String getPhoneId() {
        String androidId = null;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
        {
            androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        else
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE}, 1);
        }


        //2ac737533919dc24
        Log.d("phoneIdThing", "ID IS: " + androidId );
        return androidId;
    }


    private boolean sendPosition() {

        Log.d("PERIODIC UPDATE", "SO: sending..."   );
        Log.d("phoneIdThing", "ID IS: " + this.deviceId );

        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            Location currentLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);


            if(currentLocation == null)
            {
                currentLocation = new Location("");
                currentLocation.setLatitude(46.7559d);
                currentLocation.setLongitude(23.5915d);
                Log.d("LOCATION", "HARDCODED");
            }

            if (currentLocation != null) {
                double lat = currentLocation.getLatitude();
                double longi = currentLocation.getLongitude();

                Log.d("LOCATION", "Lat: " + lat + ", Long: " + longi);

               return postRequest( String.valueOf(lat), String.valueOf(longi), deviceId);
            } else {
                 Log.d("OOPS", "GPS error");
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        }
        return false;
    }


    private boolean postRequest(String lat, String lng, String terminalId) {
        HttpURLConnection con = null;
        try {
            Log.d("PERIODIC UPDATE", "SO: im trying"   );

            EditText ipField = findViewById(R.id.textIP);
            String ip = ipField.getText().toString();

            EditText portField = findViewById(R.id.textPORT);
            String port = portField.getText().toString();

            String postURL = "http://" + ip + ":" + port + "/positions";
            Log.d("URL IS", "URL = " + postURL);

            URL obj = new URL(postURL);
            con = (HttpURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");


            con.setDoOutput(true);
            OutputStream os = con.getOutputStream();

            os.write(String.format(POSITION_TEXT_FORMAT, lat, lng, terminalId).getBytes());
            os.flush();
            os.close();



            Log.d("PERIODIC UPDATE", "SO: ok i guess"   );
            int responseCode = con.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }

                in.close();

                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e) {

            e.printStackTrace();
            return false;
        }
        finally
        {
            if (con != null)
            {
                con.disconnect();
            }
        }
    }




}


